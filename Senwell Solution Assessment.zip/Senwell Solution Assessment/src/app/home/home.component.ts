import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  loginform!: FormGroup;
  loginuser: any;
  // username: any;
  role: any;
  Requestform: any;
  loading = false;
  submitted = false;

  constructor(public fb:FormBuilder,  private formBuilder: FormBuilder,private router:Router) {

  }
  
  ngOnInit(): void {
  
    
    this.Requestform = this.formBuilder.group({
    
      username: ['', Validators.required],
      password: ['', Validators.required],
      recaptcha: ['', Validators.required]
    });

  }
  get f() { return this.Requestform.controls; }


 /* onSubmit() {

    this.submitted = true;
    if (this.Requestform.invalid) {
      return;
    }
   console.log(this.Requestform.value);
    

  }*/
/*  siteKey:string="6Le0v4AeAAAAACuw4fbZhOUeXk6o3H0W0WcNXDFh";*/


  onSubmit(form:any ){

    this.submitted = true;
    if(this.  Requestform.valid)
    {
       localStorage.setItem("userName",this.  Requestform.get('userName')?.value);
       localStorage.setItem("passWord",this.  Requestform.get('passWord')?.value);  
       this.clear();
       this.  Requestform.disable();
       this.router.navigate(['registration']);
    }
}
clear()
{
 this.Requestform.patchValue({
   userName:'',
   passWord:''
 });
}
}